import { base44 } from './base44Client';


export const Song = base44.entities.Song;

export const Playlist = base44.entities.Playlist;



// auth sdk:
export const User = base44.auth;